#include <iostream>

using namespace std;

void masuk_tak();

int main()
{
masuk_tak();
}

void masuk_tak()
{
	char ans;
	
	cout<<"Dia shoot masuk tak? (answer y-yes atau n-tidak)"<<endl;
	

	ans=' ';
	while(ans!='y' && ans!='n')
	{
		cin>>ans;
		if(ans!='n' && ans!='y')
		cout<<"cakap lah bebetul, try again: "<<endl;
	}

	if(ans=='n')
	{
		cout<<endl<<"the fudge?!";
		masuk_tak();
	}
	cout<<endl<<"chantek!"<<endl;
}


