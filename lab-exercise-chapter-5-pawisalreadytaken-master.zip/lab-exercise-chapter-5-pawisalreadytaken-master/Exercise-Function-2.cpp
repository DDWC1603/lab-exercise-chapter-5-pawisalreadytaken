//this is an unfinish program
//finish up this program
//Muhammad Faris Danial A17Dw4143

#include<iostream>

using namespace std;

int main ()

{


int sum(int x,int y)
{
	int result;
	result = x+y;

}

}
